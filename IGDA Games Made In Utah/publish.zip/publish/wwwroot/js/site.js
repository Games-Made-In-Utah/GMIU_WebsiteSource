﻿// Smooth fade-in on page load
$(document).ready(function () {
    $('body').addClass('fade-in');
});
